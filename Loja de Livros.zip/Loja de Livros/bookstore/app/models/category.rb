class Category < ApplicationRecord
    has_many :book
end
